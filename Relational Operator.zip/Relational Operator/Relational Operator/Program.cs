﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Relational_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 12;
            if (a == b)
                Console.WriteLine("A and b is Equal");
            if (a < b)
                Console.WriteLine("A is smaller");
            if (a > b)
                Console.WriteLine("A is larger");
            if (a != b)
                Console.WriteLine("a not equals o b");
            if (a <= b)
                Console.WriteLine("A is less than equal to b");
            if (a >= b)
                Console.WriteLine("a is Greater htan equal to B");
            Console.ReadLine();
        }
    }
}
