﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arithmatic_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 20, c;
            c = (a + b);
            Console.WriteLine("Addition is " + c);
            c = (a - b);
            Console.WriteLine("Substration is " + c);
            c = (a * b);
            Console.WriteLine("Multilication is " + c);
            c = (a / b);
            Console.WriteLine("Division is " + c);
            c = (a % b);
            Console.WriteLine("Module is " + c);

            Console.ReadLine();
        }
    }
}
