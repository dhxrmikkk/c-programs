﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jagged_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] array = new int[2][];

            array[0] = new int[2] { 1, 2 };
            array[1] = new int[4] { 5, 6, 7, 8 };

            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 0; j < array[i].Length; j++)
                {
                    Console.Write(array[i][j] + " ");
                }
            }
            Console.ReadLine();
        }
    }
}
