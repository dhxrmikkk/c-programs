﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace For_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            for (i = 1; i <= 10; i++)
                Console.WriteLine(i);
            Console.ReadLine();
        }
    }
}
