﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace While_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            i=1;
            while(i<=10)
            {
                Console.WriteLine(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
