﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace dml
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string sql = "select * from dml";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "ID";

            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "username";

            comboBox3.DataSource = dt;
            comboBox3.DisplayMember = "password";
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.Show();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text==""||comboBox2.Text == "" || comboBox3.Text == "")
            {
                MessageBox.Show("no record found !", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string sql = "delete from dml where username='" + comboBox2.Text + "' and password='" + comboBox3.Text + "'and id='"+comboBox1.Text+"'";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                MessageBox.Show("Record deleted !", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clear();
            }
        }
        private void clear()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = "update dml set username='"+comboBox2.Text+"' , password='"+comboBox3.Text+"' where id='"+comboBox1.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Record updated !", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}