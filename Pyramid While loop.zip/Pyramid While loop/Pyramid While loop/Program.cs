﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pyramid_While_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            i = 1;
            while (i <= 5)
            {
                i++;
                j = 1;
                while (j <= i)
                {
                    Console.Write("$");
                    j++;
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
