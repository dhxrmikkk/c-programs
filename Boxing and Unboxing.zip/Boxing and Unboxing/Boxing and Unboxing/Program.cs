﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Boxing_and_Unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 50;
            Object obj = a;

            int b = (int)obj;

            Console.Write(b);
            Console.Read();
        }
    }
}
