﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace One_Dimenssional_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] car = { "BMW", "Mustang", "Bentely", "Royce", "Ford" };
            foreach (string s in car)
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
        }
    }
}
