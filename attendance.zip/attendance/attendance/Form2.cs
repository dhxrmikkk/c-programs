﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace attendance
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "select * from student where stream='" + comboBox1.Text + "' and division='" + comboBox2.Text + "' ORDER BY roll_no";
            SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                comboBox3.DataSource = dt;
                comboBox3.DisplayMember = "roll_no";
            }
            else
            {
                MessageBox.Show("No Records Found!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            string dt1 = dt.ToShortDateString();
            string attn = "";
            if (comboBox4.Text == "Present")
            {
                attn = "P";
            }
            else if (comboBox4.Text == "Absent")
            {
                attn = "A";
            }
            else if (comboBox4.Text == "Leave")
            {
                attn = "L";
            }
            string sql1 = "select * from Attnd where stream1='" + comboBox1.Text + "' and div1='" + comboBox2.Text + "' and allrollno='" + comboBox3.Text + "' and date='" + dt1 + "'";
            SqlDataAdapter da1 = new SqlDataAdapter(sql1,Class1.cn);
            DataTable dt3 = new DataTable();
            da1.Fill(dt3);

            if (dt3.Rows.Count == 0)
            {
                string sql = "insert into Attnd values('" + comboBox1.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + attn + "','" + dt1 + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql,Class1.cn);
                DataTable dt2 = new DataTable();
                int a = da.Fill(dt2);
                if (a == 0)
                {
                    MessageBox.Show("Attendance Taken");
                    clear();
                }
                else
                {
                    MessageBox.Show("There Was Some Error");
                    clear();
                }
            }
            else
            {
                MessageBox.Show("Attendance ALready Taken!");
                clear();
            }
        }
        private void clear()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            comboBox4.Text = "";
            comboBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
