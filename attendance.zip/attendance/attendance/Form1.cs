﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace attendance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear()
        {
            if (textBox1.Text != "" || comboBox1.Text != "" || comboBox2.Text != "" || textBox2.Text != "" || textBox3.Text != "")
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                textBox1.Focus();
            }
            else
            {
                MessageBox.Show("Nothing to clear !", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || comboBox1.Text == "" || comboBox2.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                string sql = "insert into student values('" + textBox1.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                int a = da.Fill(dt);

                if (a == 0)
                {
                    MessageBox.Show("record inserted !", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                  MessageBox.Show("please enter values !", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please enter Details !","",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string sql = "select * from student where stream='" + comboBox1.Text + "',and div='" + comboBox2.Text + "',and roll_no='" + textBox2.Text + "' ";
            SqlDataAdapter da1 = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);

            if (dt1.Rows.Count > 0)
            {
                MessageBox.Show("Duplicate Record!!!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}
