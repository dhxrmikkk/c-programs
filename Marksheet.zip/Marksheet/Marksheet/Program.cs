﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int s1, s2, s3, s4, tot, pr;

            Console.WriteLine("Enter Mark of Sub 1 : ");
            s1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Mark of Sub 2 : ");
            s2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Mark of Sub 3 : ");
            s3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Mark of Sub 4 : ");
            s4 = Convert.ToInt32(Console.ReadLine());

            tot = s1 + s2 + s3 + s4;
            Console.WriteLine("Total is : " + tot);

            pr = tot / 4;
            Console.WriteLine("Percentage is : " + pr);

            if (pr >= 70)
            {
                Console.WriteLine("Distinction");
            }
            else if (pr >= 60 || pr < 70)
            {
                Console.WriteLine("First Class");
            }
            else if (pr >= 50 || pr < 60)
            {
                Console.WriteLine("Second Class");
            }
            else if (pr >= 40 || pr < 50)
            {
                Console.WriteLine("Third Class");
            }
            else if (pr >= 30 || pr < 40)
            {
                Console.WriteLine("Fourth Class");
            }
            else
            {
                Console.WriteLine("Fail");
            }
            Console.ReadLine();
        }
    }
}