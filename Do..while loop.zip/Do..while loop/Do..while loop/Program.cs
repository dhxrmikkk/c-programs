﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Do._.while_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            i = 1;
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i <= 10);
            Console.ReadLine();
        }
    }
}
