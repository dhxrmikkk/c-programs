﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logical_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5;
            Console.WriteLine(x > 3 && x < 10);
            Console.WriteLine(x > 3 || x < 4);
            Console.WriteLine(!(x > 3 && x < 10));

            Console.ReadLine();
        }
    }
}
