﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pyramid_Do._.While_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            i = 1;
            do
            {
                j = 1;
                do
                {
                    Console.Write("&");
                    j++;
                }
                while (j <= i);
                Console.WriteLine();
                i++;
            }
            while (i <= 5);
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
