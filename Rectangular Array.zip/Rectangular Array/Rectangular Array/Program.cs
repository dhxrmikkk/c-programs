﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rectangular_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] enfield=new string[2,2];
            {
                {"350","550"};
                {"Thunderbird","Himaliyan"};
            };
            foreach(string val1 in enfield)
            {
                Console.WriteLine(val1);
            }
            Console.ReadLine();
        }
    }
}